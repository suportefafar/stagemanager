# Design System FAFAR · UFMG

Sistema visual Bootstrap da Faculdade de Farmácia da UFMG, com duas variações oficiais:

- **Institucional** — interfaces diretas, densas e orientadas a serviço. É a evolução do `bootstrap-operacional.html` e do frontend da intranet.
- **Acadêmica** — páginas editoriais, acadêmicas e de presença pública, com títulos serifados e ritmo mais amplo. É a evolução do `bootstrap-academico.html`.

O pacote inclui Bootstrap 5.3.8, tokens, componentes, shells de aplicação e site, interações acessíveis e um sprite de ícones. Não carregue Bootstrap separadamente.

## Comece aqui

Para implementar uma interface ou orientar outro agente, leia primeiro [`DESIGN_SYSTEM.md`](DESIGN_SYSTEM.md). A documentação visual está em [`index.html`](index.html).

Exemplos completos:

- [`bootstrap-operacional.html`](bootstrap-operacional.html) — aplicação institucional com sidebar.
- [`bootstrap-academico.html`](bootstrap-academico.html) — site acadêmico com masthead e navegação horizontal.

## Uso

```html
<link rel="stylesheet" href="/dist/latest/farmacia-ds.min.css">
<script defer src="/dist/latest/farmacia-ds.min.js"></script>

<body data-fafar-theme="institucional">
  ...
</body>
```

Troque o atributo para a outra variação:

```html
<body data-fafar-theme="academico">
```

Ícones usam o sprite sem dependência externa:

```html
<svg class="icon" aria-hidden="true">
  <use href="/dist/latest/icons.svg#calendar"></use>
</svg>
```

## Desenvolvimento

```bash
npm install
npm run build
```

Arquivos de autoria:

```text
src/
├── farmacia-ds.scss        # Bootstrap + ordem das camadas
├── farmacia-ds.js          # Bootstrap JS e interações FAFAR
├── icons.svg               # sprite de ícones
└── styles/
    ├── _tokens.scss        # primitivos e os dois temas
    ├── _base.scss          # tipografia, foco e acessibilidade
    ├── _components.scss    # componentes compartilhados
    ├── _shells.scss        # site, aplicação e autenticação
    └── _patterns.scss      # feed, calendário, editor e catálogo
```

Saídas de produção:

```text
dist/latest/
dist/v2026.08/
```

Use `latest` em aplicações mantidas junto com o design system e fixe `v2026.08` quando a estabilidade for mais importante que atualizações automáticas.

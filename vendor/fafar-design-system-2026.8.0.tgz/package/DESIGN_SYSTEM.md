# Referência canônica — Design System FAFAR

Este arquivo é a fonte de verdade para criar novas interfaces da Faculdade de Farmácia da UFMG. Ele foi escrito para consulta humana e para ser incluído como contexto em prompts de implementação.

## 1. Identidade do sistema

O design system preserva três sinais visuais em qualquer produto:

1. **Amarelo FAFAR (`#F2B600`)** para marca, seleção e ações principais.
2. **Grafite (`#333333`)** para estrutura, texto e contraste.
3. **Superfícies claras e quentes** em vez de cinzas azulados genéricos.

A interface deve parecer pública, sóbria e funcional. Evite gradientes decorativos, excesso de arredondamento, sombras fortes, glassmorphism e componentes com aparência de aplicativo de consumo.

## 2. Escolha da variação

### Institucional

Use `data-fafar-theme="institucional"` em:

- sistemas administrativos e aplicações autenticadas;
- centrais de serviço, filas, cadastros e dashboards;
- páginas institucionais que pedem uma voz direta e contemporânea;
- telas com alta densidade de dados.

Características: fonte de sistema sem serifa, corpo de `15px`, raios discretos, canvas `#F4F2EC`, painéis compactos e foco amarelo com contorno grafite.

### Acadêmica

Use `data-fafar-theme="academico"` em:

- sites acadêmicos, departamentos, laboratórios e programas;
- notícias, pesquisa, extensão, ensino e conteúdo editorial;
- páginas públicas que precisam transmitir tradição e leitura prolongada.

Características: Georgia nos títulos, corpo de `16px`, maior respiro, papel `#FBFAF6`, bordas quentes e foco azul de alta visibilidade.

### Tema e shell são decisões independentes

O tema controla tipografia, densidade, superfícies e estados. O shell controla a arquitetura da página:

- **Shell de site**: `.utility-bar`, `.masthead`, `.main-navbar`, conteúdo em `.container-xxl` e `.footer--site`.
- **Shell de aplicação**: `.app-shell`, `.sidebar`, `.main-column`, `.topbar`, `.page-content` e `.footer--app`.
- **Shell de autenticação**: `.authentication-page`, `.auth-shell`, `.auth-panel`, `.auth-brand` e `.auth-form`.

Assim, um site institucional pode usar o shell horizontal com o tema institucional, sem receber a tipografia acadêmica.

## 3. Instalação

O CSS já contém Bootstrap 5.3.8. Não inclua outro Bootstrap ou reset.

```html
<link rel="stylesheet" href="https://design-system.farmacia.ufmg.br/dist/latest/farmacia-ds.min.css">
<script defer src="https://design-system.farmacia.ufmg.br/dist/latest/farmacia-ds.min.js"></script>
```

```html
<body data-fafar-theme="institucional">
```

Para fixar a versão:

```html
<link rel="stylesheet" href="https://design-system.farmacia.ufmg.br/dist/v2026.08/farmacia-ds.min.css">
<script defer src="https://design-system.farmacia.ufmg.br/dist/v2026.08/farmacia-ds.min.js"></script>
```

## 4. Tokens

Prefira os nomes semânticos. Os aliases antigos (`--fafar-gold`, `--fafar-canvas` etc.) existem para compatibilidade com a intranet.

### Cores semânticas

| Token | Papel |
|---|---|
| `--fafar-color-accent` | marca e ação principal |
| `--fafar-color-accent-strong` | borda e estado ativo do amarelo |
| `--fafar-color-accent-soft` | fundos de destaque |
| `--fafar-color-ink` | texto e estrutura |
| `--fafar-color-ink-strong` | títulos e fundos escuros |
| `--fafar-color-muted` | texto secundário |
| `--fafar-color-canvas` | fundo da página |
| `--fafar-color-surface` | cards e painéis |
| `--fafar-color-surface-subtle` | cabeçalhos de tabela e áreas auxiliares |
| `--fafar-color-border` | divisórias principais |
| `--fafar-color-border-soft` | divisórias internas |
| `--fafar-color-link` | links no fundo claro |
| `--fafar-color-focus` | foco de teclado |

### Espaçamento

| Token | Valor |
|---|---:|
| `--fafar-space-1` | 4px |
| `--fafar-space-2` | 8px |
| `--fafar-space-3` | 12px |
| `--fafar-space-4` | 16px |
| `--fafar-space-5` | 24px |
| `--fafar-space-6` | 32px |
| `--fafar-space-7` | 48px |
| `--fafar-space-8` | 64px |

Use utilitários Bootstrap (`p-3`, `gap-2`, `mb-4`) para composição. Use os tokens ao escrever um componente novo.

### Forma e elevação

- `--fafar-radius-sm`: controles e badges.
- `--fafar-radius-md`: painéis institucionais.
- `--fafar-radius-lg`: conteúdo social, diálogos e agrupamentos especiais.
- `--fafar-shadow-sm`: separação leve de painel.
- `--fafar-shadow-md`: superfícies elevadas.
- `--fafar-shadow-lg`: diálogos.

## 5. Tipografia

- Nunca defina uma webfont externa para o corpo. A pilha local garante desempenho e privacidade.
- No tema acadêmico, títulos usam Georgia e textos funcionais continuam sem serifa.
- Use apenas um `h1` por página e não escolha nível de título pelo tamanho visual.
- Use `.eyebrow`, `.page-eyebrow` ou `.section-eyebrow` para contexto curto em caixa alta.
- Limite textos longos com `.text-reading` (`68ch`).
- Não use corpo menor que `14px` para conteúdo essencial.

```html
<header class="page-header d-flex justify-content-between gap-3 mb-4">
  <div>
    <p class="eyebrow mb-1">Patrimônio</p>
    <h1 class="h2 mb-1">Equipamentos</h1>
    <p class="text-body-secondary mb-0">Itens sob responsabilidade do setor.</p>
  </div>
</header>
```

## 6. Componentes canônicos

### Painel

```html
<section class="panel">
  <header class="panel-header">
    <h2 class="h5 mb-0">Título do painel</h2>
  </header>
  <div class="panel-body">Conteúdo</div>
</section>
```

`.surface-card` e `.academic-card` são aliases. Em código novo, prefira `.panel` para dados e `.surface-card` para conteúdo editorial independente.

### Botões

```html
<button class="btn btn-brand" type="submit">Salvar</button>
<button class="btn btn-charcoal" type="button">Publicar</button>
<button class="btn btn-outline-dark" type="button">Cancelar</button>
<button class="btn btn-outline-danger" type="button">Excluir</button>
```

- Uma região deve ter, em geral, uma ação `.btn-brand`.
- A ação destrutiva nunca deve ser amarela.
- Botão só com ícone precisa de `aria-label`.
- Não use cor para distinguir “Salvar” de “Cancelar” sem texto claro.

### Formulários

```html
<div>
  <label class="form-label field-required" for="assunto">Assunto</label>
  <input class="form-control is-invalid" id="assunto" aria-invalid="true" aria-describedby="erro-assunto">
  <div class="invalid-feedback" id="erro-assunto">Informe um assunto.</div>
</div>
```

- Labels são visíveis; placeholder não substitui label.
- Erros ficam junto ao campo e entram em `aria-describedby`.
- Use `.form-text` para instruções.
- Campos têm altura mínima de 44px.

### Feedback

```html
<div class="feedback feedback-success" role="status">
  <svg class="icon" aria-hidden="true"><use href="/dist/latest/icons.svg#check"></use></svg>
  <div><strong class="d-block">Reserva confirmada</strong>O horário foi incluído na agenda.</div>
</div>
```

Variações: `feedback-info`, `feedback-warning`, `feedback-danger`. Use `role="alert"` somente para erro urgente; mensagens informativas usam `role="status"`.

### Status

```html
<span class="status-badge status-new">Novo</span>
<span class="status-badge status-progress">Em atendimento</span>
<span class="status-badge status-waiting">Aguardando</span>
<span class="status-badge status-danger">Cancelado</span>
<span class="status-badge status-neutral">Arquivado</span>
```

O ponto e o texto evitam dependência exclusiva da cor. Para semântica estável entre temas, também existem `status-success`, `status-info` e `status-warning`.

### Tabela operacional

```html
<div class="table-responsive">
  <table class="table operational-table align-middle">
    <caption class="visually-hidden">Lista de equipamentos</caption>
    <thead><tr><th scope="col">Tombo</th><th scope="col">Descrição</th></tr></thead>
    <tbody><tr><th scope="row">1640321</th><td>Balança analítica</td></tr></tbody>
  </table>
</div>
```

Sempre use `.table-responsive`, `scope` nos cabeçalhos e caption visível ou visualmente oculto. Não simule tabela com cards quando a comparação por coluna for a tarefa principal.

### Indicador

```html
<article class="panel metric-card p-3">
  <span class="metric-icon"><svg class="icon"><use href="/dist/latest/icons.svg#calendar"></use></svg></span>
  <p class="metric-value">12</p>
  <p class="metric-label">Reservas hoje</p>
</article>
```

### Ação rápida

```html
<a class="quick-action" href="/reservas/new">
  <span class="quick-action-icon"><svg class="icon"><use href="/dist/latest/icons.svg#calendar"></use></svg></span>
  <span><strong>Reservar sala</strong><small>Consulte espaços e horários.</small></span>
</a>
```

### Estado vazio

```html
<div class="empty-state">
  <div>
    <span class="empty-state-icon"><svg class="icon"><use href="/dist/latest/icons.svg#inbox"></use></svg></span>
    <h2 class="h5 mt-3">Nenhum resultado</h2>
    <p class="text-body-secondary">Ajuste os filtros ou crie um registro.</p>
    <a class="btn btn-brand" href="/new">Criar registro</a>
  </div>
</div>
```

Um estado vazio explica o que ocorreu e oferece uma próxima ação quando ela existe.

### Linha do tempo

```html
<ol class="timeline">
  <li class="timeline-item">
    <time class="timeline-time" datetime="2026-08-27T09:42">09:42</time>
    <span class="timeline-dot" aria-hidden="true"></span>
    <div class="timeline-content"><strong>Atendimento iniciado</strong></div>
  </li>
</ol>
```

### Abas e paginação

Use o markup e os atributos ARIA do Bootstrap. Abas representam visões irmãs do mesmo contexto; não esconda etapas obrigatórias de formulário em abas.

## 7. Shell de site

Estrutura recomendada para sites acadêmicos ou institucionais:

```html
<body data-fafar-theme="academico">
  <a class="skip-link" href="#conteudo">Ir para o conteúdo</a>
  <header>
    <div class="utility-bar">...</div>
    <div class="masthead">...</div>
    <nav class="navbar navbar-expand-xl main-navbar">...</nav>
  </header>
  <main id="conteudo">...</main>
  <footer class="footer footer--site">...</footer>
</body>
```

Use `.container-xxl` como largura principal. Reserve containers mais estreitos para leitura longa.

## 8. Shell de aplicação

Estrutura recomendada para aplicações autenticadas:

```html
<body data-fafar-theme="institucional">
  <a class="skip-link" href="#conteudo">Pular para o conteúdo</a>
  <div class="app-shell">
    <aside class="sidebar d-none d-xl-flex flex-column">...</aside>
    <div class="main-column">
      <header class="topbar d-flex align-items-center">...</header>
      <main id="conteudo" class="page-content">...</main>
      <footer class="footer footer--app">...</footer>
    </div>
  </div>
</body>
```

A navegação móvel usa o Offcanvas do Bootstrap. O JavaScript do pacote mantém `aria-expanded` sincronizado.

## 9. Ícones

Use `dist/latest/icons.svg`. Nomes disponíveis:

`home`, `menu`, `search`, `plus`, `check`, `alert`, `info`, `close`, `arrow-right`, `arrow-left`, `chevron-down`, `calendar`, `clock`, `ticket`, `box`, `key`, `users`, `user`, `building`, `settings`, `file`, `inbox`, `edit`, `trash`, `download`, `logout`, `flask`, `monitor`, `wrench`.

```html
<svg class="icon" aria-hidden="true">
  <use href="/dist/latest/icons.svg#search"></use>
</svg>
```

- Ícones decorativos recebem `aria-hidden="true"`.
- Um ícone informativo recebe nome pelo texto adjacente ou por `aria-label` no controle.
- Não use emoji como ícone de interface.

## 10. JavaScript

O bundle expõe `window.FAFAR` e `window.bootstrap`.

```js
FAFAR.setTheme("academico")
FAFAR.init(document)
```

Ele oferece:

- todos os componentes JavaScript do Bootstrap;
- sincronização acessível do Offcanvas;
- inicialização opt-in de tooltips;
- abertura de `<dialog>` com `data-fafar-dialog-open="#id"`;
- atalho `Ctrl/Cmd + K` para `[data-fafar-global-search]`;
- compatibilidade com `turbo:load` em Rails.

## 11. Padrões adicionais da intranet

O pacote inclui as classes maduras encontradas na aplicação real:

- `.details-list` e `.details-grid`;
- `.global-search-*`;
- `.feed-page`, `.feed-composer`, `.feed-post` e `.feed-comment-*`;
- `.permission-grid` e `.permission-option`;
- `.initial-password`, `.one-time-code` e `.one-time-secret`;
- `.calendar-frame`/`.reservation-calendar-frame` e variáveis do FullCalendar;
- `.rich-text-editor` e integração visual com Trix.

Use esses padrões quando o domínio exigir. Eles não devem aparecer apenas para ornamentar uma página simples.

## 12. Acessibilidade e conteúdo

- Toda página começa com `.skip-link`.
- Foco nunca é removido. Os dois temas têm foco próprio de alto contraste.
- Alvo interativo tem ao menos 40–44px sempre que possível.
- Cor nunca é o único sinal de status.
- Modais têm título, descrição e foco devolvido à origem pelo Bootstrap.
- A ordem DOM deve permanecer lógica sem CSS.
- Respeite `prefers-reduced-motion`; o pacote já reduz animações.
- Escreva ações com verbo e objeto: “Criar reserva”, não “Confirmar” fora de contexto.
- Datas, horários, siglas e consequências devem ser explícitos.

## 13. Regras para novos componentes

1. Procure primeiro uma composição de Bootstrap + componente existente.
2. Use tokens semânticos; não copie hexadecimais para o novo componente.
3. O componente precisa funcionar nos dois temas ou declarar claramente que pertence a um shell.
4. Inclua estados normal, hover, focus, active, disabled, erro e vazio quando aplicáveis.
5. Teste em 320px, 768px, 1200px e com zoom de 200%.
6. Documente o markup canônico nesta referência e demonstre em `index.html`.
7. Não crie uma terceira linguagem visual local.

## 14. Prompt recomendado para outro webapp

> Use como fonte de verdade o design system em `~/app/services-infra/design-system/`. Leia primeiro `DESIGN_SYSTEM.md`, depois consulte `index.html` e o exemplo correspondente. Use `data-fafar-theme="institucional"` para fluxos administrativos ou `data-fafar-theme="academico"` para conteúdo acadêmico/editorial. Reutilize os tokens, componentes, shells e padrões existentes; não invente outra paleta, tipografia, raio, sombra ou biblioteca de ícones. O CSS já inclui Bootstrap 5.3.8.

## 15. Referências visuais do repositório

- `bootstrap-operacional.html`: composição institucional completa.
- `bootstrap-academico.html`: composição acadêmica completa.
- `index.html`: catálogo interativo dos dois temas.
- `src/styles/`: implementação legível e modular.

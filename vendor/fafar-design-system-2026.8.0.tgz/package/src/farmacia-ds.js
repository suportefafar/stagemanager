import * as bootstrap from "bootstrap"

const THEMES = new Set(["institucional", "academico"])
const VERSION = "2026.08"

function resolveTarget(reference) {
  if (!reference) return null
  if (reference instanceof Element) return reference
  return document.querySelector(reference)
}

function setTheme(theme, target = document.body) {
  if (!THEMES.has(theme)) throw new Error(`Tema FAFAR inválido: ${theme}`)

  const element = resolveTarget(target) || document.body
  element.dataset.fafarTheme = theme
  element.dispatchEvent(new CustomEvent("fafar:themechange", { bubbles: true, detail: { theme } }))
  return theme
}

function initBootstrapComponents(root = document) {
  root.querySelectorAll('[data-bs-toggle="tooltip"]').forEach((element) => {
    bootstrap.Tooltip.getOrCreateInstance(element)
  })
}

function initOffcanvasAccessibility(root = document) {
  root.querySelectorAll(".offcanvas").forEach((panel) => {
    const trigger = panel.id ? root.querySelector(`[data-bs-target="#${CSS.escape(panel.id)}"]`) : null
    if (!trigger) return

    panel.addEventListener("shown.bs.offcanvas", () => trigger.setAttribute("aria-expanded", "true"))
    panel.addEventListener("hidden.bs.offcanvas", () => trigger.setAttribute("aria-expanded", "false"))
  })
}

function initNativeDialogs(root = document) {
  root.addEventListener("click", (event) => {
    const openButton = event.target.closest("[data-fafar-dialog-open]")
    const closeButton = event.target.closest("[data-fafar-dialog-close]")

    if (openButton) {
      const dialog = resolveTarget(openButton.dataset.fafarDialogOpen)
      if (dialog instanceof HTMLDialogElement && !dialog.open) dialog.showModal()
    }

    if (closeButton) {
      const dialog = closeButton.closest("dialog")
      if (dialog?.open) dialog.close(closeButton.value || "close")
    }
  })

  root.querySelectorAll("dialog[data-fafar-close-backdrop]").forEach((dialog) => {
    dialog.addEventListener("click", (event) => {
      if (event.target === dialog) dialog.close("backdrop")
    })
  })
}

function initGlobalSearchShortcut(root = document) {
  document.addEventListener("keydown", (event) => {
    if (!(event.ctrlKey || event.metaKey) || event.key.toLowerCase() !== "k") return

    const dialog = root.querySelector("[data-fafar-global-search]")
    if (!(dialog instanceof HTMLDialogElement)) return

    event.preventDefault()
    if (!dialog.open) dialog.showModal()
    requestAnimationFrame(() => dialog.querySelector('input[type="search"]')?.focus())
  })
}

function initThemeControls(root = document) {
  const updateControls = (theme) => {
    root.querySelectorAll("[data-fafar-theme-set]").forEach((control) => {
      control.setAttribute("aria-pressed", String(control.dataset.fafarThemeSet === theme))
    })
  }

  root.addEventListener("click", (event) => {
    const control = event.target.closest("[data-fafar-theme-set]")
    if (!control) return

    const theme = setTheme(control.dataset.fafarThemeSet, control.dataset.fafarThemeTarget || "body")
    updateControls(theme)
  })

  updateControls(document.body?.dataset.fafarTheme || "institucional")
}

function init(root = document) {
  if (root.documentElement?.dataset.fafarInitialized === "true") return

  initBootstrapComponents(root)
  initOffcanvasAccessibility(root)
  initNativeDialogs(root)
  initGlobalSearchShortcut(root)
  initThemeControls(root)

  if (root.documentElement) root.documentElement.dataset.fafarInitialized = "true"
}

const FAFAR = Object.freeze({
  VERSION,
  themes: Object.freeze(Array.from(THEMES)),
  bootstrap,
  init,
  setTheme
})

window.FAFAR = FAFAR
window.bootstrap = window.bootstrap || bootstrap

document.addEventListener("DOMContentLoaded", () => init())
document.addEventListener("turbo:load", () => {
  delete document.documentElement.dataset.fafarInitialized
  init()
})

export { FAFAR, bootstrap, init, setTheme }
